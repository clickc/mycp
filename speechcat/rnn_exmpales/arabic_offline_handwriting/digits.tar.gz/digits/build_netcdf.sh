#! /bin/bash
./digit_offline.py trainFileNames.txt arabic_offline.nc
