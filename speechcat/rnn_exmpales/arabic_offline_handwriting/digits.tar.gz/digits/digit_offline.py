#!/usr/bin/env python
import netcdf_helpers
from optparse import OptionParser
import sys
from PIL import Image
from numpy import *
import re

inputMean = 226.8663
inputStd = 81.62196

#command line options
parser = OptionParser()
parser.add_option("-l", "--lookupfile", action="store", type="string", dest="lookupFile", default="digit_loopup.txt", help="latin/arabic lookup filename")
parser.add_option("-p", "--primarychars", action="store_true", dest="primaryChars", default=False, help="use primary characters only?")
parser.add_option("-u", "--unicode", action="store_true", dest="unicode", default=False, help="use unicode characters from town names?")
parser.add_option("-w", "--wholewords", action="store_true", dest="wholeWords", default=False, help="whole word targets?")
parser.add_option("-d", "--dictfile", action="store", type="string", dest="dictFile", default="latin_dict.txt", help="dict file (for whole word targets)")
parser.add_option("-b", "--backwards", action="store_true", dest="backwards", default=False, help="feed in targets backwards?")


#constants
ligatureString = 'llL'

#parse command line options
(options, args) = parser.parse_args()
if (len(args) < 2):
	print "usage: -options input_filename output_filename"
	print options
	sys.exit(2)

inputFilename = args[0]
outputFilename = args[1]
print options
print "input filename", inputFilename
print "output filename", outputFilename

def convertToPrimaries (labelString):
	return lab.replace('A', ' ').replace('B', ' ').replace('E', ' ').replace('M', ' ').strip().split(' ')

if options.unicode:
	labels = set()
elif options.wholeWords:
	labels = set()
	for l in file(options.dictFile).readlines():
		if l <> "":
			labels.add(l.split()[0])
else:
	#read in labels
	labels = []
	for l in file(options.lookupFile).readlines():
		if l <> "":
	#		print l
			lab = l.strip()
			if (options.primaryChars):
				for pl in convertToPrimaries(lab):
					if pl not in labels:
						labels.append(pl)
			else:
				labels.append(lab)
if len(labels):
	print len(labels),'labels'
	print labels

print "lq labels init:",labels
#read in input files
filenames = file(inputFilename).readlines()
seqTags = []
seqDims = []
targetStrings = []
wordTargetStrings = []
seqLengths = []
for f in filenames:
	fname = f.strip()
	if fname <> "":
		#read in image dimensions
		print "reading image dimensions", fname
		image = Image.open(fname)
		dims = (image.size[1], image.size[0])
		seqLengths.append(dims[0] * dims[1])
		seqTags.append(fname)
		seqDims.append(dims)
		print image.size
		
		#read in transcription
		truFilename = fname.replace('tif','tru')

                wordTarget='111'
                wordTargetStrings.append(wordTarget)		
                targetString=fname.split("_")[1]
                targetStrings.append(targetString)
			
if options.unicode:
	labels = list(labels)
	print len(labels),'labels'
	print labels
			
totalLen = sum(seqLengths)
print 'totalLen', totalLen
inputs = zeros((totalLen,1), 'f')
offset = 0
for filename in seqTags:
	print "reading image file", filename
	image = Image.open(filename).transpose(Image.FLIP_TOP_BOTTOM).transpose(Image.ROTATE_270)
	for i in image.getdata():
		inputs[offset][0] = (float(i) - inputMean)/inputStd
		offset += 1

#create a new .nc file
file = netcdf_helpers.NetCDFFile(outputFilename, 'w')

#create the dimensions
print "numSeqs<->seqLengths:",seqLengths
netcdf_helpers.createNcDim(file,'numSeqs',len(seqLengths))
print "numTimesteps<->len(inputs):",len(inputs)
netcdf_helpers.createNcDim(file,'numTimesteps',len(inputs))
print "inputPattSize<->len(inputs[0]):",len(inputs[0])
netcdf_helpers.createNcDim(file,'inputPattSize',len(inputs[0]))
print "numDims<->2:",2
netcdf_helpers.createNcDim(file,'numDims',2)
print "numLabels<->len(labels):",len(labels)
netcdf_helpers.createNcDim(file,'numLabels',len(labels))

#create the variables
print "seqTags<->seqTags:",seqTags
netcdf_helpers.createNcStrings(file,'seqTags',seqTags,('numSeqs','maxSeqTagLength'),'sequence tags')
print "labels<->labels:",labels
netcdf_helpers.createNcStrings(file,'labels',labels,('numLabels','maxLabelLength'),'labels')
print "wordTargetStrings<->wordTargetStrings:",wordTargetStrings
netcdf_helpers.createNcStrings(file,'wordTargetStrings',wordTargetStrings,('numSeqs','maxWordTargStringLength'),'target strings')
print "targetStrings<->targetStrings:",targetStrings
netcdf_helpers.createNcStrings(file,'targetStrings',targetStrings,('numSeqs','maxTargStringLength'),'target strings')
print "seqLengths<->seqLengths:",seqLengths
netcdf_helpers.createNcVar(file,'seqLengths',seqLengths,'i',('numSeqs',),'sequence lengths')
print "seqDims<->seqDims:",seqDims
netcdf_helpers.createNcVar(file,'seqDims',seqDims,'i',('numSeqs','numDims'),'sequence dimensions')
print "inputs<->inputs:",inputs
netcdf_helpers.createNcVar(file,'inputs',inputs,'f',('numTimesteps','inputPattSize'),'input patterns')

#write the data to disk
print "writing data to", outputFilename
file.close()

